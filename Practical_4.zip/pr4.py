import json

# Open and read the JSON file
with open("pr4.json", "r") as file:
    data = json.load(file)

# Print the stored books
for book in data["ProgrammingBooks"]:
    print(f"{book['Title']} ({book['Edition']}) - {book['Author']}")
