import javax.xml.parsers.*;
import org.w3c.dom.*;
import java.io.File;

public class pr6_3 {
    public static void main(String[] args) {
        try {
            File file = new File("pr6_3.xml");
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(file);
            doc.getDocumentElement().normalize();

            NodeList nList = doc.getElementsByTagName("employee");

            System.out.println("Employee Information:");
            for (int i = 0; i < nList.getLength(); i++) {
                Node node = nList.item(i);
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    Element emp = (Element) node;
                    String id = emp.getAttribute("id");
                    String name = emp.getElementsByTagName("name").item(0).getTextContent();
                    String dept = emp.getElementsByTagName("department").item(0).getTextContent();
                    String salary = emp.getElementsByTagName("salary").item(0).getTextContent();

                    System.out.println("ID: " + id + ", Name: " + name + ", Department: " + dept + ", Salary: " + salary);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
